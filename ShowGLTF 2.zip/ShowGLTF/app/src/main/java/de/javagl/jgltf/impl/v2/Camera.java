package de.javagl.jgltf.impl.v2;

/**
 * Camera的投影。节点可以引用Camera的投影来应用变换以将Camera的投影放置在场景中。
 * <p>
 * A camera's projection. A node can reference a camera to apply a
 * transform to place the camera in the scene.
 * <p>
 * Auto-generated for camera.schema.json
 */
public class Camera extends GlTFChildOfRootProperty {
    /**
     * 透视投影
     */
    public static final String PERSPECTIVE = "perspective";
    /**
     * 正交投影
     */
    public static final String ORTHOGRAPHIC = "orthographic";
    /**
     * 包含创建正交投影矩阵的属性的正交摄影机。（可选）<p>
     * An orthographic camera containing properties to create an orthographic
     * projection matrix. (optional)
     */
    private CameraOrthographic orthographic;
    /**
     * 包含创建透视投影矩阵的属性的透视照相机。（可选）<p>
     * A perspective camera containing properties to create a perspective
     * projection matrix. (optional)
     */
    private CameraPerspective perspective;
    /**
     * 指定相机是使用透视投影还是正交投影。（必需）<br>
     * 有效值：[“perspective”，“orthographic”]
     * <p>
     * Specifies if the camera uses a perspective or orthographic projection.
     * (required)<br>
     * Valid values: ["perspective", "orthographic"]
     */
    private String type;

    /**
     * An orthographic camera containing properties to create an orthographic
     * projection matrix. (optional)
     *
     * @param orthographic The orthographic to set
     */
    public void setOrthographic(CameraOrthographic orthographic) {
        if (orthographic == null) {
            this.orthographic = orthographic;
            return;
        }
        this.orthographic = orthographic;
    }

    /**
     * An orthographic camera containing properties to create an orthographic
     * projection matrix. (optional)
     *
     * @return The orthographic
     */
    public CameraOrthographic getOrthographic() {
        return this.orthographic;
    }

    /**
     * A perspective camera containing properties to create a perspective
     * projection matrix. (optional)
     *
     * @param perspective The perspective to set
     */
    public void setPerspective(CameraPerspective perspective) {
        if (perspective == null) {
            this.perspective = perspective;
            return;
        }
        this.perspective = perspective;
    }

    /**
     * A perspective camera containing properties to create a perspective
     * projection matrix. (optional)
     *
     * @return The perspective
     */
    public CameraPerspective getPerspective() {
        return this.perspective;
    }

    /**
     * Specifies if the camera uses a perspective or orthographic projection.
     * (required)<br>
     * Valid values: ["perspective", "orthographic"]
     *
     * @param type The type to set
     * @throws NullPointerException     If the given value is <code>null</code>
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setType(String type) {
        if (type == null) {
            throw new NullPointerException((("Invalid value for type: " + type) + ", may not be null"));
        }
        if ((!"perspective".equals(type)) && (!"orthographic".equals(type))) {
            throw new IllegalArgumentException((("Invalid value for type: " + type) + ", valid: [\"perspective\", \"orthographic\"]"));
        }
        this.type = type;
    }

    /**
     * Specifies if the camera uses a perspective or orthographic projection.
     * (required)<br>
     * Valid values: ["perspective", "orthographic"]
     *
     * @return The type
     */
    public String getType() {
        return this.type;
    }
}
