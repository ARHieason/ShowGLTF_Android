package de.javagl.jgltf.impl.v2;

/**
 * 纹理及其取样器。
 * <p>
 * A texture and its sampler.
 * <p>
 * Auto-generated for texture.schema.json
 */
public class Texture extends GlTFChildOfRootProperty {
    /**
     * 此纹理使用的采样器的索引。未定义时，应使用具有重复包装和自动过滤功能的采样器。（可选）
     * <p>
     * The index of the sampler used by this texture. When undefined, a
     * sampler with repeat wrapping and auto filtering should be used.
     * (optional)
     */
    private Integer sampler;
    /**
     * 此纹理使用的图像的索引。（可选）
     * <p>
     * The index of the image used by this texture. (optional)
     */
    private Integer source;

    /**
     * The index of the sampler used by this texture. When undefined, a
     * sampler with repeat wrapping and auto filtering should be used.
     * (optional)
     *
     * @param sampler The sampler to set
     */
    public void setSampler(Integer sampler) {
        if (sampler == null) {
            this.sampler = sampler;
            return;
        }
        this.sampler = sampler;
    }

    /**
     * The index of the sampler used by this texture. When undefined, a
     * sampler with repeat wrapping and auto filtering should be used.
     * (optional)
     *
     * @return The sampler
     */
    public Integer getSampler() {
        return this.sampler;
    }

    /**
     * The index of the image used by this texture. (optional)
     *
     * @param source The source to set
     */
    public void setSource(Integer source) {
        if (source == null) {
            this.source = source;
            return;
        }
        this.source = source;
    }

    /**
     * The index of the image used by this texture. (optional)
     *
     * @return The source
     */
    public Integer getSource() {
        return this.source;
    }

}
