package de.javagl.jgltf.until;

public class TypeUtil {
    public static class ShortUtil {
        /**
         * Converts the argument to an {@code int} by an unsigned
         * conversion.  In an unsigned conversion to an {@code int}, the
         * high-order 16 bits of the {@code int} are zero and the
         * low-order 16 bits are equal to the bits of the {@code short} argument.
         * <p>
         * Consequently, zero and positive {@code short} values are mapped
         * to a numerically equal {@code int} value and negative {@code
         * short} values are mapped to an {@code int} value equal to the
         * input plus 2<sup>16</sup>.
         *
         * @param x the value to convert to an unsigned {@code int}
         * @return the argument converted to {@code int} by an unsigned
         * conversion
         */
        public static int toUnsignedInt(short x) {
            return ((int) x) & 0xffff;
        }
    }

    public static class IntegerUtil {
        /**
         * Converts the argument to a {@code long} by an unsigned
         * conversion.  In an unsigned conversion to a {@code long}, the
         * high-order 32 bits of the {@code long} are zero and the
         * low-order 32 bits are equal to the bits of the integer
         * argument.
         * <p>
         * Consequently, zero and positive {@code int} values are mapped
         * to a numerically equal {@code long} value and negative {@code
         * int} values are mapped to a {@code long} value equal to the
         * input plus 2<sup>32</sup>.
         *
         * @param x the value to convert to an unsigned {@code long}
         * @return the argument converted to {@code long} by an unsigned
         * conversion
         * @since 1.8
         */
        public static long toUnsignedLong(int x) {
            return ((long) x) & 0xffffffffL;
        }
    }
}
