/**
 * Implementation of the glTF structure. The classes in this package
 * are automatically generated from the schema. They may change when
 * the schema is updated, and should not be modified manually.
 */
package de.javagl.jgltf.impl.v1;

