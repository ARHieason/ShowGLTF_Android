package de.javagl.jgltf.impl.v2;

/**
 * 有关GLTF资产的元数据。
 * <p>
 * Metadata about the glTF asset.
 * <p>
 * Auto-generated for asset.schema.json
 */
public class Asset extends GlTFProperty {
    /**
     * 版权信息
     * <p>
     * A copyright message suitable for display to credit the content
     * creator. (optional)
     */
    private String copyright;
    /**
     * 制作gltf模型的工具。用于debug调试<p>
     * Tool that generated this glTF model. Useful for debugging. (optional)
     */
    private String generator;
    /**
     * 模型的gltf的版本<p>
     * The glTF version that this asset targets. (required)
     */
    private String version;
    /**
     * 最低目标的gltf版本<p>
     * The minimum glTF version that this asset targets. (optional)
     */
    private String minVersion;

    /**
     * A copyright message suitable for display to credit the content
     * creator. (optional)
     *
     * @param copyright The copyright to set
     */
    public void setCopyright(String copyright) {
        if (copyright == null) {
            this.copyright = copyright;
            return;
        }
        this.copyright = copyright;
    }

    /**
     * A copyright message suitable for display to credit the content
     * creator. (optional)
     *
     * @return The copyright
     */
    public String getCopyright() {
        return this.copyright;
    }

    /**
     * Tool that generated this glTF model. Useful for debugging. (optional)
     *
     * @param generator The generator to set
     */
    public void setGenerator(String generator) {
        if (generator == null) {
            this.generator = generator;
            return;
        }
        this.generator = generator;
    }

    /**
     * Tool that generated this glTF model. Useful for debugging. (optional)
     *
     * @return The generator
     */
    public String getGenerator() {
        return this.generator;
    }

    /**
     * The glTF version that this asset targets. (required)
     *
     * @param version The version to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setVersion(String version) {
        if (version == null) {
            throw new NullPointerException((("Invalid value for version: " + version) + ", may not be null"));
        }
        this.version = version;
    }

    /**
     * The glTF version that this asset targets. (required)
     *
     * @return The version
     */
    public String getVersion() {
        return this.version;
    }

    /**
     * The minimum glTF version that this asset targets. (optional)
     *
     * @param minVersion The minVersion to set
     */
    public void setMinVersion(String minVersion) {
        this.minVersion = minVersion;
    }

    /**
     * The minimum glTF version that this asset targets. (optional)
     *
     * @return The minVersion
     */
    public String getMinVersion() {
        return this.minVersion;
    }
}
