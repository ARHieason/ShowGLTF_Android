package de.javagl.jgltf.impl.v2;

/**
 * 过滤和包装模式的纹理采样器属性。
 * <p>
 * Auto-generated for sampler.schema.json
 */
public class Sampler extends GlTFChildOfRootProperty {
    /**
     * 放大滤镜。（可选）<br>
     * 有效值：[9728,9729]<br>
     * Magnification filter. (optional)<br>
     * Valid values: [9728, 9729]
     */
    private Integer magFilter;
    /**
     * 缩小过滤器。（可选）<br>
     * 有效值：[9728,9729,9984,9985,9986,9987]<br>
     * Minification filter. (optional)<br>
     * Valid values: [9728, 9729, 9984, 9985, 9986, 9987]
     */
    private Integer minFilter;
    /**
     * S 环绕模式。（可选）<br>
     * 默认：10497<br>
     * 有效值： [33071, 33648, 10497]<br>
     * s wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     */
    private Integer wrapS;
    /**
     * T 环绕模式。（可选）<br>
     * 默认：10497<br>
     * 有效值： [33071, 33648, 10497]<br>
     * t wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     */
    private Integer wrapT;

    /**
     * Magnification filter. (optional)<br>
     * Valid values: [9728, 9729]
     *
     * @param magFilter The magFilter to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setMagFilter(Integer magFilter) {
        if (magFilter == null) {
            this.magFilter = magFilter;
            return;
        }
        if ((magFilter != 9728) && (magFilter != 9729)) {
            throw new IllegalArgumentException((("Invalid value for magFilter: " + magFilter) + ", valid: [9728, 9729]"));
        }
        this.magFilter = magFilter;
    }

    /**
     * Magnification filter. (optional)<br>
     * Valid values: [9728, 9729]
     *
     * @return The magFilter
     */
    public Integer getMagFilter() {
        return this.magFilter;
    }

    /**
     * Minification filter. (optional)<br>
     * Valid values: [9728, 9729, 9984, 9985, 9986, 9987]
     *
     * @param minFilter The minFilter to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setMinFilter(Integer minFilter) {
        if (minFilter == null) {
            this.minFilter = minFilter;
            return;
        }
        if ((((((minFilter != 9728) && (minFilter != 9729)) && (minFilter != 9984)) && (minFilter != 9985)) && (minFilter != 9986)) && (minFilter != 9987)) {
            throw new IllegalArgumentException((("Invalid value for minFilter: " + minFilter) + ", valid: [9728, 9729, 9984, 9985, 9986, 9987]"));
        }
        this.minFilter = minFilter;
    }

    /**
     * Minification filter. (optional)<br>
     * Valid values: [9728, 9729, 9984, 9985, 9986, 9987]
     *
     * @return The minFilter
     */
    public Integer getMinFilter() {
        return this.minFilter;
    }

    /**
     * s wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     *
     * @param wrapS The wrapS to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setWrapS(Integer wrapS) {
        if (wrapS == null) {
            this.wrapS = wrapS;
            return;
        }
        if (((wrapS != 33071) && (wrapS != 33648)) && (wrapS != 10497)) {
            throw new IllegalArgumentException((("Invalid value for wrapS: " + wrapS) + ", valid: [33071, 33648, 10497]"));
        }
        this.wrapS = wrapS;
    }

    /**
     * s wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     *
     * @return The wrapS
     */
    public Integer getWrapS() {
        return this.wrapS;
    }

    /**
     * Returns the default value of the wrapS<br>
     *
     * @return The default wrapS
     * @see #getWrapS
     */
    public Integer defaultWrapS() {
        return 10497;
    }

    /**
     * t wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     *
     * @param wrapT The wrapT to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setWrapT(Integer wrapT) {
        if (wrapT == null) {
            this.wrapT = wrapT;
            return;
        }
        if (((wrapT != 33071) && (wrapT != 33648)) && (wrapT != 10497)) {
            throw new IllegalArgumentException((("Invalid value for wrapT: " + wrapT) + ", valid: [33071, 33648, 10497]"));
        }
        this.wrapT = wrapT;
    }

    /**
     * t wrapping mode. (optional)<br>
     * Default: 10497<br>
     * Valid values: [33071, 33648, 10497]
     *
     * @return The wrapT
     */
    public Integer getWrapT() {
        return this.wrapT;
    }

    /**
     * Returns the default value of the wrapT<br>
     *
     * @return The default wrapT
     * @see #getWrapT
     */
    public Integer defaultWrapT() {
        return 10497;
    }
}
