package de.javagl.jgltf.impl.v2;

public class AnimationChannel extends GlTFProperty {
    /**
     * 此动画中用于计算目标值的采样器索引。（必须属性）<br>
     * The index of a sampler in this animation used to compute the value for
     * the target. (required)
     */
    private Integer sampler;
    /**
     * 指向目标的节点和TRS属性的索引。（必须属性）<br>
     * The index of the node and TRS property to target. (required)
     */
    private AnimationChannelTarget target;

    /**
     * The index of a sampler in this animation used to compute the value for
     * the target. (required)
     *
     * @param sampler The sampler to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setSampler(Integer sampler) {
        if (sampler == null) {
            throw new NullPointerException((("Invalid value for sampler: " + sampler) + ", may not be null"));
        }
        this.sampler = sampler;
    }

    /**
     * The index of a sampler in this animation used to compute the value for
     * the target. (required)
     *
     * @return The sampler
     */
    public Integer getSampler() {
        return this.sampler;
    }

    /**
     * The index of the node and TRS property to target. (required)
     *
     * @param target The target to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setTarget(AnimationChannelTarget target) {
        if (target == null) {
            throw new NullPointerException((("Invalid value for target: " + target) + ", may not be null"));
        }
        this.target = target;
    }

    /**
     * The index of the node and TRS property to target. (required)
     *
     * @return The target
     */
    public AnimationChannelTarget getTarget() {
        return this.target;
    }

}
