package de.javagl.jgltf.impl.v2;

/**
 * 用于创建texture的图像数据。{@link Image}可以由{@link Image#uri}或{@link Image#bufferView}索引引用。在后一种情况下需要{@link Image#mimeType}。
 * <p>
 * Image data used to create a texture. Image can be referenced by URI or
 * `bufferView` index. `mimeType` is required in the latter case.
 * <p>
 * Auto-generated for image.schema.json
 */
public class Image extends GlTFChildOfRootProperty {
    /**
     * jpeg格式
     */
    public static final String JPEG = "image/jpeg";
    /**
     * png格式
     */
    public static final String PNG = "image/png";

    /**
     * 图像的uri
     * <p>
     * The uri of the image. (optional)
     */
    private String uri;
    /**
     * 图片的格式要求（可选属性）<br>
     * 可选属性:[{@link Image#JPEG},{@link Image#PNG}]
     * <p>
     * The image's MIME type. (optional)<br>
     * Valid values: ["image/jpeg", "image/png"]
     */
    private String mimeType;
    /**
     * The index of the bufferView that contains the image. Use this instead
     * of the image's uri property. (optional)
     */
    private Integer bufferView;

    /**
     * The uri of the image. (optional)
     *
     * @param uri The uri to set
     */
    public void setUri(String uri) {
        if (uri == null) {
            this.uri = uri;
            return;
        }
        this.uri = uri;
    }

    /**
     * The uri of the image. (optional)
     *
     * @return The uri
     */
    public String getUri() {
        return this.uri;
    }

    /**
     * The image's MIME type. (optional)<br>
     * Valid values: ["image/jpeg", "image/png"]
     *
     * @param mimeType The mimeType to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setMimeType(String mimeType) {
        if (mimeType == null) {
            this.mimeType = mimeType;
            return;
        }
        if ((!JPEG.equals(mimeType)) && (!PNG.equals(mimeType))) {
            throw new IllegalArgumentException((("Invalid value for mimeType: " + mimeType) + ", valid: [" + JPEG + "," + PNG + "]"));
        }
        this.mimeType = mimeType;
    }

    /**
     * 图片的格式要求（可选属性）<br>
     * 可选属性:[{@link Image#JPEG},{@link Image#PNG}]
     * The image's MIME type. (optional)<br>
     * Valid values: ["image/jpeg", "image/png"]
     *
     * @return The mimeType
     */
    public String getMimeType() {
        return this.mimeType;
    }

    /**
     * The index of the bufferView that contains the image. Use this instead
     * of the image's uri property. (optional)
     *
     * @param bufferView The bufferView to set
     */
    public void setBufferView(Integer bufferView) {
        if (bufferView == null) {
            this.bufferView = bufferView;
            return;
        }
        this.bufferView = bufferView;
    }

    /**
     * The index of the bufferView that contains the image. Use this instead
     * of the image's uri property. (optional)
     *
     * @return The bufferView
     */
    public Integer getBufferView() {
        return this.bufferView;
    }
}
