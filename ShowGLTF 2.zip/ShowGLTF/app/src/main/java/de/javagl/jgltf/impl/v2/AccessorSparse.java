package de.javagl.jgltf.impl.v2;

/**
 * 稀疏存储不同于属性的初始化值<br>
 * Sparse storage of attributes that deviate from their initialization value.
 * <p>
 * Auto-generated for accessor.sparse.schema.json
 */
public class AccessorSparse extends GlTFProperty {
    /**
     * 存储在稀疏数组中的条目数。（必须属性）<br>
     * 最小值：1<br>
     * Number of entries stored in the sparse array. (required)<br>
     * Minimum: 1 (inclusive)
     */
    private Integer count;
    /**
     * 指向那些访问器属性的大小为“count”的索引数组偏离其初始化值。指标必须严格增加。（必须属性）<br>
     * Index array of size `count` that points to those accessor attributes
     * that deviate from their initialization value. Indices must strictly
     * increase. (required)
     */
    private AccessorSparseIndices indices;
    /**
     * Array of size `count` times number of components, storing the
     * displaced accessor attributes pointed by `indices`. Substituted values
     * must have the same `componentType` and number of components as the
     * base accessor. (required)
     */
    private AccessorSparseValues values;

    /**
     * Number of entries stored in the sparse array. (required)<br>
     * Minimum: 1 (inclusive)
     *
     * @param count The count to set
     * @throws NullPointerException     If the given value is <code>null</code>
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setCount(Integer count) {
        if (count == null) {
            throw new NullPointerException((("Invalid value for count: " + count) + ", may not be null"));
        }
        if (count < 1) {
            throw new IllegalArgumentException("count < 1");
        }
        this.count = count;
    }

    /**
     * Number of entries stored in the sparse array. (required)<br>
     * Minimum: 1 (inclusive)
     *
     * @return The count
     */
    public Integer getCount() {
        return this.count;
    }

    /**
     * Index array of size `count` that points to those accessor attributes
     * that deviate from their initialization value. Indices must strictly
     * increase. (required)
     *
     * @param indices The indices to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setIndices(AccessorSparseIndices indices) {
        if (indices == null) {
            throw new NullPointerException((("Invalid value for indices: " + indices) + ", may not be null"));
        }
        this.indices = indices;
    }

    /**
     * Index array of size `count` that points to those accessor attributes
     * that deviate from their initialization value. Indices must strictly
     * increase. (required)
     *
     * @return The indices
     */
    public AccessorSparseIndices getIndices() {
        return this.indices;
    }

    /**
     * Array of size `count` times number of components, storing the
     * displaced accessor attributes pointed by `indices`. Substituted values
     * must have the same `componentType` and number of components as the
     * base accessor. (required)
     *
     * @param values The values to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setValues(AccessorSparseValues values) {
        if (values == null) {
            throw new NullPointerException((("Invalid value for values: " + values) + ", may not be null"));
        }
        this.values = values;
    }

    /**
     * Array of size `count` times number of components, storing the
     * displaced accessor attributes pointed by `indices`. Substituted values
     * must have the same `componentType` and number of components as the
     * base accessor. (required)
     *
     * @return The values
     */
    public AccessorSparseValues getValues() {
        return this.values;
    }

}
