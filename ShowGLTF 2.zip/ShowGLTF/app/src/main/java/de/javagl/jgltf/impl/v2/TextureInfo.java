package de.javagl.jgltf.impl.v2;

/**
 * 对纹理的引用。
 * <p>
 * Reference to a texture.
 * <p>
 * Auto-generated for textureInfo.schema.json
 */
public class TextureInfo extends GlTFProperty {
    /**
     * texture的索引
     * <p>
     * The index of the texture. (required)
     */
    private Integer index;
    /**
     * 纹理的texcoord属性的集合索引，用于纹理坐标映射。（可选）<p>
     * 默认值：0
     * <p>
     * 最小值：0（含0）
     * <p>
     * The set index of texture's TEXCOORD attribute used for texture
     * coordinate mapping. (optional)<br>
     * Default: 0<br>
     * Minimum: 0 (inclusive)
     */
    private Integer texCoord;

    /**
     * The index of the texture. (required)
     *
     * @param index The index to set
     * @throws NullPointerException If the given value is <code>null</code>
     */
    public void setIndex(Integer index) {
        if (index == null) {
            throw new NullPointerException((("Invalid value for index: " + index) + ", may not be null"));
        }
        this.index = index;
    }

    /**
     * The index of the texture. (required)
     *
     * @return The index
     */
    public Integer getIndex() {
        return this.index;
    }

    /**
     * The set index of texture's TEXCOORD attribute used for texture
     * coordinate mapping. (optional)<br>
     * Default: 0<br>
     * Minimum: 0 (inclusive)
     *
     * @param texCoord The texCoord to set
     * @throws IllegalArgumentException If the given value does not meet
     *                                  the given constraints
     */
    public void setTexCoord(Integer texCoord) {
        if (texCoord == null) {
            this.texCoord = texCoord;
            return;
        }
        if (texCoord < 0) {
            throw new IllegalArgumentException("texCoord < 0");
        }
        this.texCoord = texCoord;
    }

    /**
     * The set index of texture's TEXCOORD attribute used for texture
     * coordinate mapping. (optional)<br>
     * Default: 0<br>
     * Minimum: 0 (inclusive)
     *
     * @return The texCoord
     */
    public Integer getTexCoord() {
        return this.texCoord;
    }

    /**
     * Returns the default value of the texCoord<br>
     *
     * @return The default texCoord
     * @see #getTexCoord
     */
    public Integer defaultTexCoord() {
        return 0;
    }
}
