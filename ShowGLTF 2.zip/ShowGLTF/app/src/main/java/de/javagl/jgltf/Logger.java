package de.javagl.jgltf;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

public class Logger {
    public static final String TRACK = "IdealNative";
    /**
     * 给加载3D模型设置的TAG
     */
    public static final String MODEL3D = "model3d";
    private static final boolean openLog = true;
    public static final String VIDEO_RECORD = "VIDEO_RECORD";
    private static Map<String, Boolean> switchMap = new HashMap<>();

    static {
        switchMap.put(TRACK, false);
        switchMap.put(MODEL3D, false);
        switchMap.put("onDrawFrame", false);
    }

    public static void LOGE(String tag, String message) {
        if (openLog) {
            if (switchMap.get(tag) == null || switchMap.get(tag)) {
                Log.e(tag, message);
            }
        }
    }


    public static void LOGW(String tag, String message) {
        if (openLog) {
            if (switchMap.get(tag) == null || switchMap.get(tag)) {
                Log.w(tag, message);
            }
        }
    }

    public static void LOGD(String tag, String message) {
        if (openLog) {
            if (switchMap.get(tag) == null || switchMap.get(tag)) {
                Log.d(tag, message);
            }
        }
    }

    public static void LOGI(String tag, String message) {
        if (openLog) {
            if (switchMap.get(tag) == null || switchMap.get(tag)) {
                Log.i(tag, message);
            }
        }
    }
}
