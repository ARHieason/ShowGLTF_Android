package com.again.showgltf;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.os.Environment;
import android.util.Log;
import android.view.Display;

import com.again.showgltf.common.RawResourceReader;
import com.again.showgltf.common.ShaderHelper;
import com.again.showgltf.common.TextureHelper;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.HashMap;
import java.util.Map;

import de.javagl.jgltf.model.AccessorModel;
import de.javagl.jgltf.model.BufferModel;
import de.javagl.jgltf.model.BufferViewModel;
import de.javagl.jgltf.model.GltfModel;
import de.javagl.jgltf.model.ImageModel;
import de.javagl.jgltf.model.MeshModel;
import de.javagl.jgltf.model.MeshPrimitiveModel;
import de.javagl.jgltf.model.NodeModel;
import de.javagl.jgltf.model.TextureModel;
import de.javagl.jgltf.model.io.GltfModelReader;


public class ModelManager {

    private static final String TAG = ModelManager.class.getSimpleName();

    private final Context mActivityContext;

    private GltfModel gltfModel;

    private GltfModelReader modelReader;

    private int mProgramHandle;

    private int mMVPMatrixHandle;

    private int mMVMatrixHandle;

    private int mLightPosHandle;

    private int mTextureUniformHandle;
    private int mPositionHandle;

    private int mNormalHandle;

    private int mTextureCoordinateHandle;

    private float[] mMVPMatrix = new float[16];
    private float[] mTemporaryMatrix = new float[16];

    private int [] textureModels = null;
    private int glTextureID = -1;
    private Map<TextureModel, Integer> textureMap = new HashMap<>();
    private Map<String,Integer> shaderHandleMap = new HashMap<>();
    private Map<String,FloatBuffer> bufferHandleMap = new HashMap<>();
    private ShortBuffer indexBuffer ;
    public static float byte2float(byte[] b, int index) {
        int l;
        l = b[index + 0];
        l &= 0xff;
        l |= ((long) b[index + 1] << 8);
        l &= 0xffff;
        l |= ((long) b[index + 2] << 16);
        l &= 0xffffff;
        l |= ((long) b[index + 3] << 24);
        return Float.intBitsToFloat(l);
    }

    public static short[] bytesToShort(byte[] bytes) {
        if(bytes==null){
            return null;
        }
        short[] shorts = new short[bytes.length/2];
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts);
        return shorts;
    }

    public static float[] byteToFloat(byte[] input) {
        float[] ret = new float[input.length/4];
        for (int x = 0; x < input.length; x+=4) {
//            ret[x/4] = ByteBuffer.wrap(input, x, 4).getFloat();
            ret[x/4] = byte2float(input,x);
        }
        return ret;
    }
    public static byte[] subBytes(byte[] src, int offset, int count) {
        byte[] bs = new byte[count];
        for (int i=0;i<count; i++) bs[i] = src[i+offset];
        return bs;
    }


    public ModelManager(final Context activityContext)
    {
        mActivityContext = activityContext;
        modelReader = new GltfModelReader(activityContext.getResources());

    }

    public void loadModel(String path)
    {
        try {
            gltfModel = modelReader.read(path);
            loadShader();
            bindShaderHandle();
            bindTexture();
            bindData();
        } catch (Exception e)
        {
            Log.e(TAG,"Load Model Error");
            Log.e(TAG,e.toString());
            e.printStackTrace();
        }
    }

    private void loadShader()
    {
        final String vertexShader = RawResourceReader.readTextFileFromRawResource(mActivityContext, R.raw.per_pixel_vertex_shader_tex_and_light);
        final String fragmentShader = RawResourceReader.readTextFileFromRawResource(mActivityContext, R.raw.per_pixel_fragment_shader_tex_and_light);

        final int vertexShaderHandle = ShaderHelper.compileShader(GLES20.GL_VERTEX_SHADER, vertexShader);
        final int fragmentShaderHandle = ShaderHelper.compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader);

        mProgramHandle = ShaderHelper.createAndLinkProgram(vertexShaderHandle, fragmentShaderHandle,
                new String[] {"a_Position",  "a_Normal", "a_TexCoordinate"});

    }
    //绑定shader里面的属性
    private void bindShaderHandle()
    {
        GLES20.glUseProgram(mProgramHandle);
        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgramHandle, "u_MVPMatrix");
        mMVMatrixHandle = GLES20.glGetUniformLocation(mProgramHandle, "u_MVMatrix");
        mLightPosHandle = GLES20.glGetUniformLocation(mProgramHandle, "u_LightPos");
        mTextureUniformHandle = GLES20.glGetUniformLocation(mProgramHandle, "u_Texture");

        mPositionHandle = GLES20.glGetAttribLocation(mProgramHandle, "a_Position");
        mNormalHandle = GLES20.glGetAttribLocation(mProgramHandle, "a_Normal");
        mTextureCoordinateHandle = GLES20.glGetAttribLocation(mProgramHandle, "a_TexCoordinate");
        shaderHandleMap.put("POSITION",mPositionHandle);
        shaderHandleMap.put("NORMAL",mNormalHandle);
        shaderHandleMap.put("TEXCOORD_0",mTextureCoordinateHandle);

    }

    //绑定纹理
    private void bindTexture()
    {
        GLES20.glUseProgram(mProgramHandle);
        textureModels = new int[gltfModel.getTextureModels().size()];
//        GLES20.glGenTextures(textureModels.length, textureModels, 0);
        for(int i=0; i<textureModels.length; i++) {
            TextureModel textureModel = gltfModel.getTextureModels().get(i);
            textureMap.put(textureModel, i);
            glTextureID = TextureHelper.loadTexture(mActivityContext, R.drawable.duck_cm);
            GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
//            ImageModel imageModel = textureModel.getImageModel();
//            ByteBuffer imageData = imageModel.getImageData();
//            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureModels[i]);
//            if(imageData != null) {
//                glTextureID = textureModels[i];
//                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 512, 512, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, imageData);
//                GLES20.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0);
//                GLES20.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 4);
//                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, textureModel.getMinFilter());
//                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, textureModel.getMagFilter());
//                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, textureModel.getWrapS());
//                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, textureModel.getWrapT());
//                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
//
//                GLES20.glActiveTexture(GL_TEXTURE0 );
//                GLES20.glBindTexture(GL_TEXTURE_2D, textureModels[i]);
//                GLES20.glUniform1i(mTextureUniformHandle, 0);
//            } else {
//                Log.e(TAG, "Image data null");
//            }
        }
    }

    private void bindData()
    {
        for(NodeModel node : gltfModel.getNodeModels()) {
            for(MeshModel mesh : node.getMeshModels()) {
                for(MeshPrimitiveModel meshPrimitive : mesh.getMeshPrimitiveModels()) {
                    Map<String, AccessorModel> map = meshPrimitive.getAttributes();
                    for (String key : map.keySet()) {
                        if (!shaderHandleMap.containsKey(key))
                            continue;
                        AccessorModel accessor = map.get(key);
                        int handle = shaderHandleMap.get(key);
                        BufferViewModel bufferView = accessor.getBufferViewModel();
                        BufferModel buffer = bufferView.getBufferModel();
                        int size = accessor.getElementType().getNumComponents();
                        int type = accessor.getComponentType();
                        int offset = accessor.getByteOffset() + bufferView.getByteOffset();
                        int stride = accessor.getByteStride();
                        if(bufferView.getByteStride() != null) {
                            stride += bufferView.getByteStride();
                        }
                        int compSize = accessor.getComponentSizeInBytes();
                        int length = accessor.getCount()*size*compSize;
                        ByteBuffer bBuffer = buffer.getBufferData();
                        ByteBuffer tempbuf = ByteBuffer.allocateDirect(length).order(ByteOrder.nativeOrder());
                        byte[] byte2 = subBytes(bBuffer.array(),offset + 4,length);
                        float[] ver = byteToFloat(byte2);
                        FloatBuffer dataFB = tempbuf.asFloatBuffer();
                        dataFB.put(ver);
                        dataFB.position(0);
                        bufferHandleMap.put(key,dataFB);
                    }

                    AccessorModel indices = meshPrimitive.getIndices();
                    if (indices!=null)
                    {
                        BufferViewModel indicesBufferViewModel = indices.getBufferViewModel();
                        BufferModel buffer = indicesBufferViewModel.getBufferModel();
                        int size = indices.getElementType().getNumComponents();
                        int count = indices.getCount();
                        int type = indices.getComponentType();
                        int offset = indices.getByteOffset() + indicesBufferViewModel.getByteOffset();
                        int compSize = indices.getComponentSizeInBytes();
                        int length = indices.getCount()*size*compSize;
                        ByteBuffer bBuffer = buffer.getBufferData();
                        ByteBuffer tempbuf = ByteBuffer.allocateDirect(length).order(ByteOrder.nativeOrder());
                        byte[] byte2 = subBytes(bBuffer.array(),offset+4,length);
                        short[] ver = bytesToShort(byte2);
                        indexBuffer = tempbuf.asShortBuffer();
                        indexBuffer.put(ver);
                        indexBuffer.position(0);
                    }
                }
            }
        }
        Log.d(TAG,"bindData finished");
    }


    public void drawModel(float[] vMatrix,float[] mMatrix,float[] pMatrix,float[] LightPos)
    {
        GLES20.glUseProgram(mProgramHandle);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, glTextureID);
        GLES20.glUniform1i(mTextureUniformHandle, 0);
        Matrix.multiplyMM(mMVPMatrix, 0, vMatrix, 0, mMatrix, 0);
        GLES20.glUniformMatrix4fv(mMVMatrixHandle, 1, false, mMVPMatrix, 0);
        Matrix.multiplyMM(mTemporaryMatrix, 0, pMatrix, 0, mMVPMatrix, 0);
        System.arraycopy(mTemporaryMatrix, 0, mMVPMatrix, 0, 16);
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mMVPMatrix, 0);

        GLES20.glUniform3f(mLightPosHandle, LightPos[0], LightPos[1], LightPos[2]);

        for(NodeModel node : gltfModel.getNodeModels()) {
            for(MeshModel mesh : node.getMeshModels()) {
                for(MeshPrimitiveModel meshPrimitive : mesh.getMeshPrimitiveModels()) {
                    Map<String, AccessorModel> map = meshPrimitive.getAttributes();
                    for (String key : map.keySet()) {
                        if (!shaderHandleMap.containsKey(key))
                            continue;
                        AccessorModel accessor = map.get(key);
                        int handle = shaderHandleMap.get(key);
                        BufferViewModel bufferView = accessor.getBufferViewModel();
                        BufferModel buffer = bufferView.getBufferModel();
                        int size = accessor.getElementType().getNumComponents();
                        int type = accessor.getComponentType();
                        int offset = accessor.getByteOffset() + bufferView.getByteOffset();
                        int stride = accessor.getByteStride();
                        if(bufferView.getByteStride() != null) {
                            stride += bufferView.getByteStride();
                        }
                        FloatBuffer dataBF = bufferHandleMap.get(key);
                        dataBF.position(0);
                        GLES20.glVertexAttribPointer(handle, size, type, false,
                                0, dataBF);
                        GLES20.glEnableVertexAttribArray(handle);
                    }

                    AccessorModel indices = meshPrimitive.getIndices();
                    if (indices!=null)
                    {
                        BufferViewModel indicesBufferViewModel = indices.getBufferViewModel();
                        BufferModel buffer = indicesBufferViewModel.getBufferModel();
                        int count = indices.getCount();
                        int type = indices.getComponentType();
                        indexBuffer.position(0);
                        GLES20.glDrawElements(meshPrimitive.getMode(), count,type,indexBuffer);
                    }else {
                        AccessorModel accessor = map.get("POSITION");
                        int count = accessor.getCount();
                        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count);
                    }
                }
            }
        }

    }

}
